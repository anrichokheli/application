package pedestriansos.application;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioAttributes;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    //private FusedLocationProviderClient fusedLocationClient;
    //private LocationCallback locationCallback;

    boolean darkModeEnabled = true;
    String URL = "https://pedestrian-sos.000webhostapp.com/";

    Uri PS_notificationSoundUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_PedestrianSOS);
        setContentView(R.layout.activity_main);
        findViewById(R.id.takePhotoButton).setOnClickListener(v -> takePhoto());
        findViewById(R.id.recordVideoButton).setOnClickListener(v -> recordVideo());
        findViewById(R.id.choosePhotoButton).setOnClickListener(v -> openFileChooser("image/*"));
        findViewById(R.id.chooseVideoButton).setOnClickListener(v -> openFileChooser("video/*"));
        //findViewById(R.id.button6).setOnClickListener(v -> darkMode(true));
        //findViewById(R.id.button7).setOnClickListener(v -> darkMode(false));
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        darkModeEnabled = sharedPreferences.getBoolean("dark_mode", true);
        darkMode(darkModeEnabled);
        SwitchCompat darkModeSwitch = findViewById(R.id.switch1);
        darkModeSwitch.setChecked(darkModeEnabled);
        darkModeSwitch.setOnClickListener(v -> darkMode(darkModeSwitch.isChecked()));
        //network networkClass = new network();

        EditText textInputElement = findViewById(R.id.editTextTextPersonName2);

        //String[] textParameters = {"postInput"};
        findViewById(R.id.button).setOnClickListener(v -> {
            openFileChooser("*/*");

            //String[] textValues = {textInputElement.getText().toString()};
            //postString(URL + "123.php", textParameters, textValues);
        });
        //fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        //createLocationRequest();
//        locationCallback = new LocationCallback() {
//            @Override
//            public void onLocationResult(LocationResult locationResult) {
//                if (locationResult == null) {
//                    Toast.makeText(getApplicationContext(), "NULL123", Toast.LENGTH_LONG).show();
//                    return;
//                }
//                for (Location location : locationResult.getLocations()) {
//                    // Update UI with location data
//                    // ...
//                    Toast.makeText(getApplicationContext(), String.valueOf(location.getLatitude()), Toast.LENGTH_LONG).show();
//                }
//            }
//        };
        findViewById(R.id.button2).setOnClickListener(v -> getLocation());
        findViewById(R.id.button3).setOnClickListener(v -> sendPedestrianSOSnotification(textInputElement.getText().toString()));

        PS_notificationSoundUri = Uri.parse("android.resource://"+getApplicationContext().getPackageName()+'/'+R.raw.psnotification);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            createNotificationChannel(getString(R.string.app_name), getString(R.string.app_name), NotificationManager.IMPORTANCE_DEFAULT, getString(R.string.notificationchannelid), PS_notificationSoundUri);
            createNotificationChannel(getString(R.string.uploadProgressNotificationChannelName), getString(R.string.uploadProgressNotificationChannelDescription), NotificationManager.IMPORTANCE_LOW, getString(R.string.uploadProgressNotificationChannelID), null);
        }
    }

    int notificationID = 0;

    private void sendNotification(int smallIcon, String title, String text, Uri sound) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, getString(R.string.notificationchannelid))
                .setSmallIcon(smallIcon)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setSound(sound)
                .setColor(Color.parseColor("#028900"));

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

// notificationId is a unique int for each notification that you must define
        notificationManager.notify(notificationID++, builder.build());
    }

    private void sendPedestrianSOSnotification(String text) {
        sendNotification(R.drawable.psnotificationicon, getString(R.string.app_name), text, PS_notificationSoundUri);
    }

    private void createNotificationChannel(String name, String description, int importance, String channelid, Uri sound) {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelid, name, importance);
            channel.setDescription(description);
            if(sound != null)
                channel.setSound(sound, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    /*@Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        *//*
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
        *//*
        darkMode(darkModeEnabled);
    }*/

    /*private String getBase64FromFile(String filePath, Bitmap.CompressFormat compressFormat)  {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Bitmap bitmap = BitmapFactory.decodeFile(filePath);
        bitmap.compress(compressFormat, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }*/
/*
    public static String convertStreamToString(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }
        reader.close();
        return sb.toString();
    }
*/
    String currentPhotoPath;
    String currentVideoPath;

    /*public String getRealPathFromURI(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = { MediaStore.Images.Media.DATA };
            cursor = context.getContentResolver().query(contentUri,  proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }*/

    private File createFile(String fileSuffix/*, String cameraDirectory*/) throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String fileName = "FILE_" + timeStamp + "_";
        File storageDir/* = null*/;
        //if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.FROYO) {
            storageDir = getExternalFilesDir(/*"camera/" + cameraDirectory*/Environment.DIRECTORY_PICTURES);
        //}
        /*else    {
            String packageName = getApplicationContext().getPackageName();
            File externalPath = Environment.getExternalStorageDirectory();
            storageDir = new File(externalPath.getAbsolutePath() +
                    "/Android/data/" + packageName + "/files");
        }*/

        // Save a file: path for use with ACTION_VIEW intents
        //currentPhotoPath = file.getAbsolutePath();
        return File.createTempFile(
                fileName,  /* prefix */
                fileSuffix,         /* suffix */
                storageDir      /* directory */
        );
    }

    //web webClass = new web();

    private void uploadFile(String filePath, String WEB_URL, String WEB_NAME, InputStream fileStream) {
        ConnectivityManager cm =
                (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        if(!isConnected)    {
            Toast.makeText(getApplicationContext(), "!CONNECTION", Toast.LENGTH_LONG).show();
            return;
        }

        int uploadProgressNotificationID = notificationID++;
        NotificationManagerCompat notificationManager2 = NotificationManagerCompat.from(this);
        NotificationCompat.Builder builder2 = new NotificationCompat.Builder(this, getString(R.string.uploadProgressNotificationChannelID));
        builder2.setContentTitle(getString(R.string.fileUploadTitle))
                /*.setContentText("Upload in progress")*/
                .setSmallIcon(R.drawable.uploadicon)
                .setPriority(NotificationCompat.PRIORITY_LOW);

// Issue the initial notification with zero progress
        int PROGRESS_MAX = 100;
        builder2.setProgress(PROGRESS_MAX, 0, false);
        notificationManager2.notify(uploadProgressNotificationID, builder2.build());

        new Thread(() -> {

            int serverResponseCode;
            String serverResponseString = null;

            HttpURLConnection conn;
            DataOutputStream dos;
            String lineEnd = "\r\n";
            String twoHyphens = "--";
            String boundary = "*****";
            int bytesRead, bytesAvailable, bufferSize;
            byte[] buffer;
            int maxBufferSize = 1024/*256*/ * 1024;

            long totalSize = 0;

            File sourceFile = null;
            if (filePath != null) {
                sourceFile = new File(filePath);
                totalSize = sourceFile.length();
            } else {
                try {
                    totalSize = fileStream.available();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            //if (!sourceFile.isFile()) {

            //dialog.dismiss();

            //Log.e("uploadFile", "Source File not exist :"
            //      +uploadFilePath + "" + uploadFileName);

            /*runOnUiThread(new Runnable() {
                public void run() {
                    messageText.setText("Source File not exist :"
                            +uploadFilePath + "" + uploadFileName);
                }
            });*/

            //return null;

            //}
            if (((sourceFile != null) && sourceFile.isFile()) || (fileStream != null)) {
                try {

                    // open a URL connection to the Servlet
                    /*File*/InputStream fileInputStream;
                    if(filePath != null) {
                        fileInputStream = new FileInputStream(sourceFile);
                    }
                    else    {
                        fileInputStream = fileStream;
                    }
                    URL url = new URL(WEB_URL);

                    // Open a HTTP  connection to  the URL
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setChunkedStreamingMode(/*256*/1024 * 1024);
                    conn.setDoInput(true); // Allow Inputs
                    conn.setDoOutput(true); // Allow Outputs
                    conn.setUseCaches(false); // Don't use a Cached Copy
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Connection", "Keep-Alive");
                    conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                    conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                    conn.setRequestProperty(WEB_NAME, filePath);

                    dos = new DataOutputStream(conn.getOutputStream());

                    dos.writeBytes(twoHyphens + boundary + lineEnd);
                    dos.writeBytes("Content-Disposition: form-data; name=\"" + WEB_NAME + "\";filename=\""
                            + filePath + "\"" + lineEnd);

                    dos.writeBytes("Content-Type:application/octet-stream \r\n");

                    dos.writeBytes(lineEnd);

                    // create a buffer of  maximum size
                    bytesAvailable = fileInputStream.available();

                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    buffer = new byte[bufferSize];

                    // read file and write it into form...
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                    int progress;

                    //int a = 0;

                    long length = 0;

                    while (bytesRead > 0) {

                        dos.write(buffer, 0, bufferSize);

                        length += bufferSize;

                        progress = (int) (((float) length / (float) totalSize) * 100);
                        builder2.setContentText(String.valueOf(progress) + '%');
                        builder2.setProgress(PROGRESS_MAX, progress, false);
                        notificationManager2.notify(uploadProgressNotificationID, builder2.build());

                        //a++;

                        bytesAvailable = fileInputStream.available();
                        bufferSize = Math.min(bytesAvailable, maxBufferSize);
                        bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                    }

                    //int finalA = a;
                    //runOnUiThread(() -> Toast.makeText(getApplicationContext(), String.valueOf(finalA), Toast.LENGTH_LONG).show());

                    // send multipart form data necesssary after file data...
                    dos.writeBytes(lineEnd);
                    dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                    // Responses from the server (code and message)
                    serverResponseCode = conn.getResponseCode();
                    //String serverResponseMessage = conn.getResponseMessage();

                    //Log.i("uploadFile", "HTTP Response is : "
                    //      + serverResponseMessage + ": " + serverResponseCode);

                    if (serverResponseCode == 200) {
                        serverResponseString = getServerResponse(conn);

                       /*runOnUiThread(new Runnable() {
                            public void run() {

                                String msg = "File Upload Completed.\n\n See uploaded file here : \n\n"
                                              +" http://www.androidexample.com/media/uploads/"
                                              +uploadFileName;

                                messageText.setText(msg);
                                Toast.makeText(UploadToServer.this, "File Upload Complete.",
                                             Toast.LENGTH_SHORT).show();
                            }
                        });*/
                    } else {
                        serverResponseString = "HTTP ERROR " + serverResponseCode;
                    }

                    //close the streams //
                    fileInputStream.close();
                    dos.flush();
                    dos.close();

                } catch (MalformedURLException ex) {

                    //dialog.dismiss();
                    ex.printStackTrace();

                  /*runOnUiThread(new Runnable() {
                      public void run() {
                          messageText.setText("MalformedURLException Exception : check script url.");
                          Toast.makeText(UploadToServer.this, "MalformedURLException",
                                                              Toast.LENGTH_SHORT).show();
                      }
                  });*/

                    //Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
                } catch (Exception e) {

                    //dialog.dismiss();
                    e.printStackTrace();

                  /*runOnUiThread(new Runnable() {
                      public void run() {
                          messageText.setText("Got Exception : see logcat ");
                          Toast.makeText(UploadToServer.this, "Got Exception : see logcat ",
                                  Toast.LENGTH_SHORT).show();
                      }
                  });
                  Log.e("Upload file to server Exception", "Exception : "
                                                   + e.getMessage(), e);*/
                }
                //dialog.dismiss();
                //return serverResponseCode;
                //return serverResponseString;


            } // End else block
            String finalServerResponseString = serverResponseString;
            runOnUiThread(() -> {
                Toast.makeText(getApplicationContext(), finalServerResponseString, Toast.LENGTH_LONG).show();
                if (finalServerResponseString.charAt(0) == '#') {
                    builder2.setContentText(getString(R.string.fileUploaded))
                            .setProgress(0, 0, false);
                    notificationManager2.notify(uploadProgressNotificationID, builder2.build());
                    ID = finalServerResponseString.substring(1, finalServerResponseString.indexOf('|'));
                    KEY = finalServerResponseString.substring(finalServerResponseString.indexOf('|') + 1);
                    getLocation();
                }
            });
        }).start();
    }

    String action;

    ActivityResultLauncher<Intent> cameraActivity = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    switch (action) {
                        case "takePhoto":
                            Toast.makeText(getApplicationContext(), currentPhotoPath, Toast.LENGTH_LONG).show();

                            uploadFile(currentPhotoPath, URL + "media.php", "file", null);

                            //setContentView(R.layout.test123);
                            //((ImageView)findViewById(R.id.imageView)).setImageBitmap(BitmapFactory.decodeFile((new File(currentPhotoPath)).getAbsolutePath()));

                            //String[] imageParameter = {"image"};
                            //String[] base64image = {"data:image/jpg;base64," + getBase64FromFile(currentPhotoPath, Bitmap.CompressFormat.JPEG)};
                            //web(URL + "media.php", imageParameter, base64image);

                        /*network cls2 = new network();
                        try {
                            cls2.postFile(currentPhotoPath,URL + "media.php", "file");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }*/
                            break;
                        case "recordVideo":
                            //assert result.getData() != null;
                            //videoPath = result.getData().getDataString();

                            Toast.makeText(getApplicationContext(), currentVideoPath, Toast.LENGTH_LONG).show();
                            uploadFile(currentVideoPath, URL + "media.php", "file", null);
                            //setContentView(R.layout.test123);
                            //((VideoView) findViewById(R.id.videoView)).setVideoPath(currentVideoPath);

                            //uploadFile(videoPath, URL + "media.php", "file");

                            //setContentView(R.layout.test123);
                            //((VideoView) findViewById(R.id.videoView)).setVideoURI(Uri.parse(videoPath));
                            break;
                    }
                }
            }
    );

    ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
            this::onActivityResult_chooseFile);

    private String cameraIntent(String cameraIntentString, String fileSuffix/*, String fileDirectory*/) {
        String currentFilePath = null;
        Intent camera_intent = new Intent(cameraIntentString);
        // Ensure that there's a camera activity to handle the intent
        if (camera_intent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File file = null;
            try {
                file = createFile(fileSuffix/*, fileDirectory*/);
                currentFilePath = file.getAbsolutePath();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (file != null) {
                Uri URI;
                if (Build.VERSION.SDK_INT >= 23) {
                    URI = FileProvider.getUriForFile(this,
                            "com.example.android.fileprovider",
                            file);
                } else {
                    URI = Uri.fromFile(file);
                }
                camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, URI);
                //action = "takePhoto";
                cameraActivity.launch(camera_intent);
            }
        }
        return currentFilePath;
    }

    private void takePhoto() {
        action = "takePhoto";
        currentPhotoPath = cameraIntent(MediaStore.ACTION_IMAGE_CAPTURE, ".jpg"/*, "photos"*/);
    }

    private void recordVideo() {
        action = "recordVideo";
        currentVideoPath = cameraIntent(MediaStore.ACTION_VIDEO_CAPTURE, ".mp4"/*, "videos"*/);
    }

    private void openFileChooser(String fileType)  {
        mGetContent.launch(fileType);
    }

    //static final int REQUEST_VIDEO_CAPTURE = 1;

    /*private void dispatchTakeVideoIntent() {
        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            //startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
            action = "recordVideo";
            takePictureActivity.launch(takeVideoIntent);
        }
    }*/

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (resultCode == RESULT_OK) {
            if(requestCode == 0)    {
                Toast.makeText(getApplicationContext(), currentPhotoPath, Toast.LENGTH_LONG).show();
            }
            //Uri videoUri = intent.getData();
            //videoView.setVideoURI(videoUri);
        }
    }*/

    private void darkMode(boolean enabled) {
        //View someView = findViewById(R.id.background);
        //View root = someView.getRootView();
        View backgroundView = findViewById(R.id.background);

        EditText textInputElement = findViewById(R.id.editTextTextPersonName2);

        if (enabled) {
            //root.setBackgroundColor(getResources().getColor(android.R.color.black));
            backgroundView.setBackgroundColor(Color.parseColor("#000000"));
            //AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

            textInputElement.setTextColor(Color.parseColor("#ffffff"));
        } else {
            //root.setBackgroundColor(getResources().getColor(android.R.color.white));
            backgroundView.setBackgroundColor(Color.parseColor("#ffffff"));
            //AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

            textInputElement.setTextColor(Color.parseColor("#000000"));
        }
        darkModeEnabled = enabled;
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferencesEditor = sharedPreferences.edit();
        sharedPreferencesEditor.putBoolean("dark_mode", darkModeEnabled);
        //if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            sharedPreferencesEditor.apply();
        //}
        /*else {
            sharedPreferencesEditor.commit();
        }*/
    }

    LocationManager locationManager;
    LocationListener locationListener;

    private void requestLocation(String provider, long minTime, float minDistance) {
        if (locationManager.isProviderEnabled(provider)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
                return;
            }
            locationManager.requestLocationUpdates(provider, minTime, minDistance, locationListener);
        }
    }

    private void getLocation() {
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                Toast.makeText(getApplicationContext(), String.valueOf(location), Toast.LENGTH_LONG).show();
                String[] uploadLocationParameters = {
                        "n",
                        "key",
                        "latitude",
                        "longitude",
                        "altitude",
                        "accuracy"
                };
                String[] uploadLocationValues = {ID,
                        KEY,
                        String.valueOf(location.getLatitude()),
                        String.valueOf(location.getLongitude()),
                        String.valueOf(location.getAltitude()),
                        String.valueOf(location.getAccuracy())
                };
                postString(URL + "location.php", uploadLocationParameters, uploadLocationValues);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {

            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {

            }
        };
        Toast.makeText(getApplicationContext(), String.valueOf(locationManager.getAllProviders()), Toast.LENGTH_LONG).show();
        requestLocation(LocationManager.GPS_PROVIDER, 60000, 0);
        requestLocation(LocationManager.NETWORK_PROVIDER, 60000, 0);
    }

//    protected void getLocation() {
//        LocationRequest locationRequest = LocationRequest.create();
//        locationRequest.setInterval(10000);
//        locationRequest.setFastestInterval(5000);
//        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
//
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return;
//        }
//        LocationServices.getFusedLocationProviderClient(MainActivity.this)
//                .requestLocationUpdates(locationRequest, new LocationCallback() {
//                    @Override
//                    public void onLocationResult(@NonNull LocationResult locationResult) {
//                        super.onLocationResult(locationResult);
//                        Toast.makeText(getApplicationContext(), "123", Toast.LENGTH_LONG).show();
//                    }
//                }, Looper.getMainLooper());
//    }

//    private void startLocationUpdates() {
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return;
//        }
//        fusedLocationClient.requestLocationUpdates(locationRequest,
//                locationCallback,
//                Looper.getMainLooper());
//    }

//    private void getLocation() {
//        Toast.makeText(getApplicationContext(), "abc", Toast.LENGTH_LONG).show();
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            Toast.makeText(getApplicationContext(), "!!!", Toast.LENGTH_LONG).show();
//            return;
//        }
//        fusedLocationClient.getLastLocation()
//                .addOnSuccessListener(this, location -> {
//                    // Got last known location. In some rare situations this can be null.
//                    Toast.makeText(getApplicationContext(), "123", Toast.LENGTH_LONG).show();
//                    if (location != null) {
//                        // Logic to handle location object
//                        Toast.makeText(getApplicationContext(), String.valueOf(location.getLatitude()), Toast.LENGTH_LONG).show();
//                    }
//                });
//    }

    String ID;
    String KEY;

    private void postString(String url, String[] POST_PARAMETERS, String[] POST_VALUES)   {
        new Thread(() -> {
            String serverResponse = /*webClass.*/postString0(url, POST_PARAMETERS, POST_VALUES);
            runOnUiThread(() -> Toast.makeText(getApplicationContext(), serverResponse, Toast.LENGTH_LONG).show());
        }).start();
    }

    public String postString0(String postUrl, String[] postParameters, String[] postValues) {
        StringBuilder data = new StringBuilder();
        boolean isFirstParameter = true;

//                     URLEncoder.encode("name", "UTF-8")
//                     + "=" + URLEncoder.encode(Name, "UTF-8");
//
//             data.append("&").append(URLEncoder.encode("email", "UTF-8")).append("=").append(URLEncoder.encode(Email, "UTF-8"));
//
//             data.append("&").append(URLEncoder.encode("user", "UTF-8")).append("=").append(URLEncoder.encode(Login, "UTF-8"));
//
//             data.append("&").append(URLEncoder.encode("pass", "UTF-8")).append("=").append(URLEncoder.encode(Pass, "UTF-8"));

        for(byte i = 0; i < postParameters.length; i++)  {
            if(isFirstParameter)
                isFirstParameter = false;
            else
                data.append('&');
            try {
                data.append(URLEncoder.encode(postParameters[i], "UTF-8")).append('=').append(URLEncoder.encode(postValues[i], "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        //String text = "";
        //BufferedReader reader=null;

        // Send data
        try
        {

            // Defined URL  where to send data
            URL url = new URL(postUrl);

            // Send POST data request

            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data.toString());
            wr.flush();

            // Get the server response
/*
                 reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                 StringBuilder sb = new StringBuilder();
                 String line;

                 // Read Server Response
                 while((line = reader.readLine()) != null)
                 {
                     // Append server response in string
                     sb.append(line).append("\n");
                 }
*/
            return getServerResponse(conn);
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
             /*finally
             {
                 try
                 {

                     assert reader != null;
                     reader.close();
                 }

                 catch(Exception ex) {
                     ex.printStackTrace();
                 }
             }*/
        return "";
    }
    private String getServerResponse(URLConnection local_httpURLConnection) throws IOException {
        InputStream inputStream = local_httpURLConnection.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null)  {
            result.append(line);
        }
        return result.toString();
    }

    private void onActivityResult_chooseFile(Uri uri) {

        setContentView(R.layout.test123);
        ((ImageView) (findViewById(R.id.imageView))).setImageURI(uri);

        if(uri != null) {
            try {
                uploadFile(null, URL + "media.php", "file", getContentResolver().openInputStream(uri));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        //Toast.makeText(getApplicationContext(), , Toast.LENGTH_LONG).show();
//uploadFile(a, URL + "media.php", "file");
    }

    /*private void postString(String url, String[] POST_PARAMETERS, String[] POST_VALUES)  {
        new Thread(() -> {
            StringBuilder nameValuePairs = new StringBuilder();
            boolean isFirstPair = true;
            for(byte i = 0; i < POST_PARAMETERS.length; i++)   {
                if(isFirstPair)
                    isFirstPair = false;
                else
                    nameValuePairs.append('&');
                nameValuePairs.append(POST_PARAMETERS[i]);
                nameValuePairs.append('=');
                nameValuePairs.append(POST_VALUES[i]);
            }
            try {
                java.net.URL urlObject = new URL(url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) urlObject.openConnection();
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setUseCaches(false);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));
                }
                else {
                    bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                }
                assert false;
                bufferedWriter.write(nameValuePairs.toString());
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                httpURLConnection.connect();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, this::onServerResponse, error -> {

        }){
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<>();
                for (byte i = 0; i < POST_PARAMETERS.length; i++) {
                    params.put(POST_PARAMETERS[i], POST_VALUES[i]);
                }
                return params;
            }
            public Map<String,String> getHeaders() {
                Map<String,String> params = new HashMap<>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };
        queue.add(stringRequest);
    }*/

}

/*class network {
    private final Executor executor;
    public network(Executor executor) {
        this.executor = executor;
    }
    public void web(String URL)   {
        executor.execute((Runnable) () -> web0(URL));
    }
    public void web0(String URL) {
        try {
            URL url = new URL("https://pedestrian-sos.000webhostapp.com/123.php?getInput=" + URL);
            HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
            urlConn.connect();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}*/