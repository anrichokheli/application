package pedestriansos.application;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    //private FusedLocationProviderClient fusedLocationClient;
    //private LocationCallback locationCallback;

    boolean darkModeEnabled = true;
    String URL = "https://pedestrian-sos.000webhostapp.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTheme(R.style.Theme_PedestrianSOS);
        setContentView(R.layout.activity_main);
        findViewById(R.id.takePhotoButton).setOnClickListener(v -> takePhoto());
        findViewById(R.id.recordVideoButton).setOnClickListener(v -> recordVideo());

        //findViewById(R.id.button6).setOnClickListener(v -> darkMode(true));
        //findViewById(R.id.button7).setOnClickListener(v -> darkMode(false));
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        darkModeEnabled = sharedPreferences.getBoolean("dark_mode", true);
        darkMode(darkModeEnabled);
        SwitchCompat darkModeSwitch = findViewById(R.id.switch1);
        darkModeSwitch.setChecked(darkModeEnabled);
        darkModeSwitch.setOnClickListener(v -> darkMode(darkModeSwitch.isChecked()));
        //network networkClass = new network();
        String[] textParameters = {"postInput"};
        String[] textValues = {((EditText) findViewById(R.id.editTextTextPersonName2)).getText().toString()};
        findViewById(R.id.button).setOnClickListener(v -> /*networkClass.*/postString(URL + "123.php", textParameters, textValues));
        //fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        //createLocationRequest();
//        locationCallback = new LocationCallback() {
//            @Override
//            public void onLocationResult(LocationResult locationResult) {
//                if (locationResult == null) {
//                    Toast.makeText(getApplicationContext(), "NULL123", Toast.LENGTH_LONG).show();
//                    return;
//                }
//                for (Location location : locationResult.getLocations()) {
//                    // Update UI with location data
//                    // ...
//                    Toast.makeText(getApplicationContext(), String.valueOf(location.getLatitude()), Toast.LENGTH_LONG).show();
//                }
//            }
//        };
        findViewById(R.id.button2).setOnClickListener(v -> getLocation());
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        /*
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
        */
        darkMode(darkModeEnabled);
    }

    /*private String getBase64FromFile(String filePath, Bitmap.CompressFormat compressFormat)  {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Bitmap bitmap = BitmapFactory.decodeFile(filePath);
        bitmap.compress(compressFormat, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }*/
/*
    public static String convertStreamToString(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }
        reader.close();
        return sb.toString();
    }
*/
    String currentPhotoPath;
    String currentVideoPath;

    /*public String getRealPathFromURI(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = { MediaStore.Images.Media.DATA };
            cursor = context.getContentResolver().query(contentUri,  proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }*/

    private File createFile(String fileSuffix/*, String cameraDirectory*/) throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String fileName = "FILE_" + timeStamp + "_";
        File storageDir/* = null*/;
        //if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.FROYO) {
        storageDir = getExternalFilesDir(/*"camera/" + cameraDirectory*/Environment.DIRECTORY_PICTURES);
        //}
        /*else    {
            String packageName = getApplicationContext().getPackageName();
            File externalPath = Environment.getExternalStorageDirectory();
            storageDir = new File(externalPath.getAbsolutePath() +
                    "/Android/data/" + packageName + "/files");
        }*/

        // Save a file: path for use with ACTION_VIEW intents
        //currentPhotoPath = file.getAbsolutePath();
        return File.createTempFile(
                fileName,  /* prefix */
                fileSuffix,         /* suffix */
                storageDir      /* directory */
        );
    }

    web webClass = new web();

    private void uploadFile(String filePath, String WEB_URL, String WEB_NAME) {
        new Thread(() -> {
            String serverResponse = webClass.uploadFile(filePath, WEB_URL, WEB_NAME);
            runOnUiThread(() -> onServerResponse(serverResponse));
        }).start();
    }

    String action;

    ActivityResultLauncher<Intent> cameraActivity = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    if (action.equals("takePhoto")) {
                        Toast.makeText(getApplicationContext(), currentPhotoPath, Toast.LENGTH_LONG).show();

                        uploadFile(currentPhotoPath, URL + "media.php", "file");

                        //setContentView(R.layout.test123);
                        //((ImageView)findViewById(R.id.imageView)).setImageBitmap(BitmapFactory.decodeFile((new File(currentPhotoPath)).getAbsolutePath()));

                        //String[] imageParameter = {"image"};
                        //String[] base64image = {"data:image/jpg;base64," + getBase64FromFile(currentPhotoPath, Bitmap.CompressFormat.JPEG)};
                        //web(URL + "media.php", imageParameter, base64image);

                        /*network cls2 = new network();
                        try {
                            cls2.postFile(currentPhotoPath,URL + "media.php", "file");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }*/
                    } else if (action.equals("recordVideo")) {
                        //assert result.getData() != null;
                        //videoPath = result.getData().getDataString();

                        Toast.makeText(getApplicationContext(), currentVideoPath, Toast.LENGTH_LONG).show();
                        uploadFile(currentVideoPath, URL + "media.php", "file");
                        //setContentView(R.layout.test123);
                        //((VideoView) findViewById(R.id.videoView)).setVideoPath(currentVideoPath);

                        //uploadFile(videoPath, URL + "media.php", "file");

                        //setContentView(R.layout.test123);
                        //((VideoView) findViewById(R.id.videoView)).setVideoURI(Uri.parse(videoPath));
                    }
                }
            }
    );

    private String cameraIntent(String cameraIntentString, String fileSuffix/*, String fileDirectory*/) {
        String currentFilePath = null;
        Intent camera_intent = new Intent(cameraIntentString);
        // Ensure that there's a camera activity to handle the intent
        if (camera_intent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            File file = null;
            try {
                file = createFile(fileSuffix/*, fileDirectory*/);
                currentFilePath = file.getAbsolutePath();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (file != null) {
                Uri URI;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    URI = FileProvider.getUriForFile(this,
                            "com.example.android.fileprovider",
                            file);
                } else {
                    URI = Uri.fromFile(file);
                }
                camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, URI);
                //action = "takePhoto";
                cameraActivity.launch(camera_intent);
            }
        }
        return currentFilePath;
    }

    private void takePhoto() {
        action = "takePhoto";
        currentPhotoPath = cameraIntent(MediaStore.ACTION_IMAGE_CAPTURE, ".jpg"/*, "photos"*/);
    }

    private void recordVideo() {
        action = "recordVideo";
        currentVideoPath = cameraIntent(MediaStore.ACTION_VIDEO_CAPTURE, ".mp4"/*, "videos"*/);
    }

    //static final int REQUEST_VIDEO_CAPTURE = 1;

    /*private void dispatchTakeVideoIntent() {
        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            //startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
            action = "recordVideo";
            takePictureActivity.launch(takeVideoIntent);
        }
    }*/

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (resultCode == RESULT_OK) {
            if(requestCode == 0)    {
                Toast.makeText(getApplicationContext(), currentPhotoPath, Toast.LENGTH_LONG).show();
            }
            //Uri videoUri = intent.getData();
            //videoView.setVideoURI(videoUri);
        }
    }*/

    private void darkMode(boolean enabled) {
        //View someView = findViewById(R.id.background);
        //View root = someView.getRootView();
        View backgroundView = findViewById(R.id.background);
        if (enabled) {
            //root.setBackgroundColor(getResources().getColor(android.R.color.black));
            backgroundView.setBackgroundColor(Color.parseColor("#000000"));
        } else {
            //root.setBackgroundColor(getResources().getColor(android.R.color.white));
            backgroundView.setBackgroundColor(Color.parseColor("#ffffff"));
        }
        darkModeEnabled = enabled;
        SharedPreferences sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferencesEditor = sharedPreferences.edit();
        sharedPreferencesEditor.putBoolean("dark_mode", darkModeEnabled);
        sharedPreferencesEditor.apply();
    }

    LocationManager locationManager;
    LocationListener locationListener;

    private void requestLocation(String provider, long minTime, float minDistance) {
        if (locationManager.isProviderEnabled(provider)) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.requestLocationUpdates(provider, minTime, minDistance, locationListener);
        }
    }

    private void getLocation() {
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                Toast.makeText(getApplicationContext(), String.valueOf(location), Toast.LENGTH_LONG).show();
                String[] uploadLocationParameters = {
                        "n",
                        "key",
                        "latitude",
                        "longitude",
                        "altitude",
                        "accuracy"
                };
                String[] uploadLocationValues = {ID,
                        KEY,
                        String.valueOf(location.getLatitude()),
                        String.valueOf(location.getLongitude()),
                        String.valueOf(location.getAltitude()),
                        String.valueOf(location.getAccuracy())
                };
                postString(URL + "location.php", uploadLocationParameters, uploadLocationValues);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {

            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {

            }
        };
        Toast.makeText(getApplicationContext(), String.valueOf(locationManager.getAllProviders()), Toast.LENGTH_LONG).show();
        requestLocation(LocationManager.GPS_PROVIDER, 60000, 0);
        requestLocation(LocationManager.NETWORK_PROVIDER, 60000, 0);
    }

//    protected void getLocation() {
//        LocationRequest locationRequest = LocationRequest.create();
//        locationRequest.setInterval(10000);
//        locationRequest.setFastestInterval(5000);
//        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
//
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return;
//        }
//        LocationServices.getFusedLocationProviderClient(MainActivity.this)
//                .requestLocationUpdates(locationRequest, new LocationCallback() {
//                    @Override
//                    public void onLocationResult(@NonNull LocationResult locationResult) {
//                        super.onLocationResult(locationResult);
//                        Toast.makeText(getApplicationContext(), "123", Toast.LENGTH_LONG).show();
//                    }
//                }, Looper.getMainLooper());
//    }

//    private void startLocationUpdates() {
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            return;
//        }
//        fusedLocationClient.requestLocationUpdates(locationRequest,
//                locationCallback,
//                Looper.getMainLooper());
//    }

//    private void getLocation() {
//        Toast.makeText(getApplicationContext(), "abc", Toast.LENGTH_LONG).show();
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            // TODO: Consider calling
//            //    ActivityCompat#requestPermissions
//            // here to request the missing permissions, and then overriding
//            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//            //                                          int[] grantResults)
//            // to handle the case where the user grants the permission. See the documentation
//            // for ActivityCompat#requestPermissions for more details.
//            Toast.makeText(getApplicationContext(), "!!!", Toast.LENGTH_LONG).show();
//            return;
//        }
//        fusedLocationClient.getLastLocation()
//                .addOnSuccessListener(this, location -> {
//                    // Got last known location. In some rare situations this can be null.
//                    Toast.makeText(getApplicationContext(), "123", Toast.LENGTH_LONG).show();
//                    if (location != null) {
//                        // Logic to handle location object
//                        Toast.makeText(getApplicationContext(), String.valueOf(location.getLatitude()), Toast.LENGTH_LONG).show();
//                    }
//                });
//    }

    String ID;
    String KEY;

    public void onServerResponse(String response) {
        Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
        if(response.charAt(0) == '#')    {
            ID = response.substring(1, response.indexOf('|'));
            KEY = response.substring(response.indexOf('|') + 1);
            getLocation();
        }
    }

    private void postString(String url, String[] POST_PARAMETERS, String[] POST_VALUES)  {


        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, this::onServerResponse, error -> {

        }){
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<>();
                for (byte i = 0; i < POST_PARAMETERS.length; i++) {
                    params.put(POST_PARAMETERS[i], POST_VALUES[i]);
                }
                return params;
            }
            public Map<String,String> getHeaders() {
                Map<String,String> params = new HashMap<>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };
        queue.add(stringRequest);
    }

}

/*class network {
    private final Executor executor;
    public network(Executor executor) {
        this.executor = executor;
    }
    public void web(String URL)   {
        executor.execute((Runnable) () -> web0(URL));
    }
    public void web0(String URL) {
        try {
            URL url = new URL("https://pedestrian-sos.000webhostapp.com/123.php?getInput=" + URL);
            HttpURLConnection urlConn = (HttpURLConnection)url.openConnection();
            urlConn.connect();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}*/