package pedestriansos.app;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.CUPCAKE)    {
            findViewById(R.id.take_photo).setOnClickListener(v -> takePhoto());
            findViewById(R.id.record_video).setOnClickListener(v -> recordVideo());
        }
        else    {
            findViewById(R.id.take_photo).setEnabled(false);
            findViewById(R.id.record_video).setEnabled(false);
        }
        findViewById(R.id.choose_photo).setOnClickListener(v -> chooseFile("image/*"));
        findViewById(R.id.choose_video).setOnClickListener(v -> chooseFile("video/*"));
        voiceRecordIntent = new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION);
        voiceRecordAvailable = voiceRecordIntent.resolveActivity(getPackageManager()) != null;
        //if(!voiceRecordAvailable)
            //((TextView)findViewById(R.id.soundUpload)).setTextColor(Color.argb(128, 255, 255, 255));
    }

    /*File createFile(String fileSuffix) throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String fileName = "FILE_" + timeStamp + "_";
        File storageDir;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.FROYO) {
            storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        }
        else    {
            String packageName = getApplicationContext().getPackageName();
            File externalPath = Environment.getExternalStorageDirectory();
            storageDir = new File(externalPath.getAbsolutePath() +
                    "/Android/data/" + packageName + "/files");
        }
        return File.createTempFile(
                fileName,
                fileSuffix,
                storageDir
        );
    }

    String cameraIntent(String cameraIntentString, String fileSuffix) {
        String currentFilePath = null;
        Intent camera_intent = new Intent(cameraIntentString);
        if (camera_intent.resolveActivity(getPackageManager()) != null) {
            File file = null;
            try {
                file = createFile(fileSuffix);
                currentFilePath = file.getAbsolutePath();
            } catch (IOException ex) {
                // Error occurred while creating the File
            }
            if (file != null) {
                Uri URI;
                if (Build.VERSION.SDK_INT >= 23) {
                    URI = FileProvider.getUriForFile(this,
                            "com.example.android.fileprovider",
                            file);
                } else {
                    URI = Uri.fromFile(file);
                }
                camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, URI);
                //cameraActivity.launch(camera_intent);
                startActivityForResult(camera_intent, 0);
            }
        }
        return currentFilePath;
    }*/

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            if (requestCode == 0) {
                uploadPhotoVideo(currentPhotoUri);
            }
            else if(requestCode == 1)   {
                uploadPhotoVideo(data.getData());
            }
            else if(requestCode == 2)   {
                setVoiceButtonEnabled(false);
                new Thread(() -> {
                    String serverResponse = postString0(URL + "sound_id_and_key.php", new String[]{"n", "key"}, new String[]{ID, KEY});
                    if(serverResponse.contains("*"))    {
                        String[] responseArray = serverResponse.split("\\*");
                        runOnUiThread(() -> uploadFileFromURI(data.getData(), URL + "sound_upload.php?id=" + responseArray[0] + "&key=" + responseArray[1]/*, "file"*/, R.id.soundUpload, R.string.voice, R.drawable.ic_microphone));
                    }
                    else    {
                        setVoiceButtonEnabled(true);
                    }
                }).start();
            }
        }
    }

    //String currentPhotoPath;
    Uri currentPhotoUri;

    @TargetApi(Build.VERSION_CODES.CUPCAKE)
    void takePhoto() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT <= 28) {
            PackageManager packageManager = getPackageManager();
            if (packageManager.checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, getPackageName()) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return;
            }
        }
        //locationUploadEnabled = true;
        //currentPhotoPath = cameraIntent(MediaStore.ACTION_IMAGE_CAPTURE, ".jpg");
        ContentValues contentValues = new ContentValues();
        //contentValues.put(MediaStore.Images.Media.TITLE, "123");
        //contentValues.put(MediaStore.Images.Media.DESCRIPTION, "456");
        currentPhotoUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, currentPhotoUri);
        startActivityForResult(intent, 0);
    }

    @TargetApi(Build.VERSION_CODES.CUPCAKE)
    void recordVideo() {
        //locationUploadEnabled = true;
        startActivityForResult(new Intent(MediaStore.ACTION_VIDEO_CAPTURE), 1);
    }

    void chooseFile(String fileType)   {
        //locationUploadEnabled = false;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(fileType);
        startActivityForResult(intent, 1);
    }

    void shareText(String text)    {
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, text);
        sendIntent.setType("text/plain");
        Intent shareIntent = Intent.createChooser(sendIntent, null);
        startActivity(shareIntent);
    }

    String URL = "https://pedestrian-sos.000webhostapp.com/";
    String ID;
    String KEY;

    boolean isNetworkConnected()    {
        ConnectivityManager cm =
                (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }

    void resetUploadStatuses()  {
        int color = Color.parseColor("#40FFFFFF");
        findViewById(R.id.fileUpload).setBackgroundColor(color);
        findViewById(R.id.soundUpload).setBackgroundColor(color);
        findViewById(R.id.descriptionUpload).setBackgroundColor(color);
        findViewById(R.id.locationUpload).setBackgroundColor(color);
    }

    void postString(String url, String[] POST_PARAMETERS, String[] POST_VALUES/*, int notificationTitle, int notificationIcon*/, int textView, int text, int drawable)   {
        setUploadStatusVisibleIfNot(textView, text, drawable);
        View uploadText = findViewById(textView);
        uploadText.setBackgroundColor(Color.parseColor("#40ffff00"));
        Toast.makeText(getApplicationContext(), getString(text) + ": " + getString(R.string.uploading), Toast.LENGTH_LONG).show();
        new Thread(() -> {
            String serverResponse = postString0(url, POST_PARAMETERS, POST_VALUES);
            runOnUiThread(() -> {
                int contentText;
                if(serverResponse.equals("1"))    {
                    uploadText.setBackgroundColor(Color.parseColor("#4000ff00"));
                    contentText = R.string.uploaded;
                }
                else    {
                    uploadText.setBackgroundColor(Color.parseColor("#40ff0000"));
                    contentText = R.string.uploadError;
                }
                Toast.makeText(getApplicationContext(), getString(text) + ": " + getString(contentText), Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    String postString0(String postUrl, String[] postParameters, String[] postValues) {
        StringBuilder data = new StringBuilder();
        boolean isFirstParameter = true;

        for(byte i = 0; i < postParameters.length; i++)  {
            if(isFirstParameter)
                isFirstParameter = false;
            else
                data.append('&');
            try {
                data.append(URLEncoder.encode(postParameters[i], "UTF-8")).append('=').append(URLEncoder.encode(postValues[i], "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        try
        {
            URL url = new URL(postUrl);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data.toString());
            wr.flush();
            return getServerResponse(conn);
        }
        catch(Exception ex) {
            ex.printStackTrace();
        }
        return "";
    }

    String getServerResponse(URLConnection local_httpURLConnection) throws IOException {
        InputStream inputStream = local_httpURLConnection.getInputStream();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null)  {
            result.append(line);
        }
        return result.toString();
    }

    Intent voiceRecordIntent;
    boolean voiceRecordAvailable;
    Button voiceButton;

    void setVoiceButtonEnabled(boolean enabled)    {
        voiceButton.setEnabled(enabled);
        if(enabled)
            voiceButton.setBackgroundColor(Color.parseColor("#ec0400"));
        else
            voiceButton.setBackgroundColor(Color.parseColor("#80ec0400"));
    }

    void recordSound()  {
        startActivityForResult(voiceRecordIntent, 2);
    }

    void description()  {
        final EditText editText = new EditText(this);
        AlertDialog.Builder builder;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.HONEYCOMB) {
            builder = new AlertDialog.Builder(this, AlertDialog.THEME_HOLO_DARK);
            editText.setTextColor(getResources().getColor(R.color.white));
            editText.setHintTextColor(Color.argb(128, 255, 255, 255));
            editText.setBackgroundColor(Color.argb(0, 0, 0, 0));
            ShapeDrawable shapeDrawable = new ShapeDrawable(new RectShape());
            shapeDrawable.getPaint().setColor(Color.WHITE);
            shapeDrawable.getPaint().setStyle(Paint.Style.STROKE);
            shapeDrawable.getPaint().setStrokeWidth(1);
            editText.setBackgroundDrawable(shapeDrawable);
        }
        else    {
            builder = new AlertDialog.Builder(this);
        }
        builder.setTitle(R.string.description);
        builder.setMessage(getString(R.string.voice) + " & " + getString(R.string.text));
        //builder.setIcon(R.drawable.ic_baseline_description_24);
        //editText.setInputType(InputType.TYPE_CLASS_TEXT);
        editText.setSingleLine(false);
        editText.setHint(R.string.writeDescription);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        if(voiceRecordAvailable) {
            voiceButton = new Button(this);
            voiceButton.setText(getString(R.string.voiceRecord));
            voiceButton.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_microphone), null, null, null);
            voiceButton.setBackgroundColor(Color.parseColor("#ec0400"));
            voiceButton.setOnClickListener(v -> recordSound());
            linearLayout.addView(voiceButton);
        }
        linearLayout.addView(editText);
        builder.setView(linearLayout);
        builder.setPositiveButton("✓ " + getString(R.string.upload), (dialog, which) -> {
            String[] parametersArray = {"n", "key", "description", "situation"};
            String[] valuesArray = {ID, KEY, editText.getText().toString(), ""};
            postString(URL + "info.php", parametersArray, valuesArray/*, R.string.descriptionUploadTitle, R.drawable.ic_text_upload*/, R.id.descriptionUpload, R.string.description, R.drawable.ic_description);
        });
        builder.setNegativeButton("✕ " + getString(R.string.cancel), (dialog, which) -> dialog.cancel());
        builder.show();
    }

    //boolean locationUploadEnabled;
    LocationManager locationManager;
    LocationListener locationListener;

    /*boolean*/void requestLocation(String provider/*, long minTime, float minDistance*/) {
        if (locationManager.isProviderEnabled(provider)) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PackageManager packageManager = getPackageManager();
                if (packageManager.checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, getPackageName()) != PackageManager.PERMISSION_GRANTED && packageManager.checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION, getPackageName()) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
                    return/* false*/;
                }
            }
            locationManager.requestLocationUpdates(provider, /*minTime*/60000, /*minDistance*/0, locationListener);
            //return true;
        }
        //return false;
    }

    void getLocation() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PackageManager packageManager = getPackageManager();
            if (packageManager.checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, getPackageName()) != PackageManager.PERMISSION_GRANTED && packageManager.checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION, getPackageName()) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);
                return;
            }
        }
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                String[] uploadLocationParameters = {
                        "n",
                        "key",
                        "latitude",
                        "longitude",
                        "altitude",
                        "accuracy"
                };
                String[] uploadLocationValues = {ID,
                        KEY,
                        String.valueOf(location.getLatitude()),
                        String.valueOf(location.getLongitude()),
                        String.valueOf(location.getAltitude()),
                        String.valueOf(location.getAccuracy())
                };
                locationManager.removeUpdates(locationListener);
                postString(URL + "location.php", uploadLocationParameters, uploadLocationValues, R.id.locationUpload, R.string.location, R.drawable.ic_location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };
        //Toast.makeText(getApplicationContext(), String.valueOf(locationManager.getAllProviders()), Toast.LENGTH_LONG).show();
        /*boolean GPS_locationRequested = */requestLocation(LocationManager.GPS_PROVIDER/*, 60000, 0*/);
        /*boolean NETWORK_locationRequested = */requestLocation(LocationManager.NETWORK_PROVIDER/*, 60000, 0*/);
        /*if(
                GPS_locationRequested
                        ||
                        NETWORK_locationRequested
        )    {
            notificationManager2.notify(locationProgressNotificationID, builder2.build());
        }*/
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == 0) {
                getLocation();
            } else if (requestCode == 1) {
                takePhoto();
            }
        }
    }

    void setUploadStatusVisibleIfNot(int view, int text, int drawable)  {
        View uploadStatusLayoutView = findViewById(R.id.uploadStatusLayout);
        if(uploadStatusLayoutView.getVisibility() == View.GONE)    {
            ((TextView)findViewById(R.id.uploadStatusTextView)).setText(R.string.uploadStatus);
            uploadStatusLayoutView.setVisibility(View.VISIBLE);
            findViewById(R.id.after_uploadStatusLayout).setVisibility(View.VISIBLE);
        }
        TextView textView = findViewById(view);
        if(textView.getVisibility() == View.GONE) {
            textView.setText(text);
            textView.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(drawable), null, null, null);
            textView.setVisibility(View.VISIBLE);
        }
    }

    void uploadFile(/*String filePath, */String WEB_URL/*, String WEB_NAME*/, InputStream fileStream/*, int notificationTitle, int notificationIcon*/, int textView, int text, int drawable) {
        String filePath = null;
        String WEB_NAME = "file";
        if(!isNetworkConnected())    {
            Toast.makeText(getApplicationContext(), "!CONNECTION", Toast.LENGTH_LONG).show();
            return;
        }
        setUploadStatusVisibleIfNot(textView, text, drawable);
        View fileText = findViewById(textView);
        fileText.setBackgroundColor(Color.parseColor("#40ffff00"));
        Toast.makeText(getApplicationContext(), getString(text) + ": " + getString(R.string.uploading), Toast.LENGTH_LONG).show();
        //boolean chunkedStream = false;
        int maxBufferSize = 1024 * 1024;
        //int chunkLen = 256 * 1024;
        new Thread(() -> {
            int serverResponseCode;
            String serverResponseString = null;
            HttpURLConnection conn;
            DataOutputStream dos;
            String lineEnd = "\r\n";
            String twoHyphens = "--";
            String boundary = "*****";
            int bytesRead, bytesAvailable, bufferSize;
            byte[] buffer;
            /*long totalSize = 0;
            File sourceFile = null;
            if (filePath != null) {
                sourceFile = new File(filePath);
                //totalSize = sourceFile.length();
            } else {
                try {
                    totalSize = fileStream.available();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }*/
            if (/*((sourceFile != null) && sourceFile.isFile()) || (*/fileStream != null/*)*/) {
                try {
                    InputStream fileInputStream;
                    /*if(filePath != null) {
                        fileInputStream = new FileInputStream(sourceFile);
                    }
                    else    {*/
                        fileInputStream = fileStream;
                    //}
                    URL url = new URL(WEB_URL);
                    conn = (HttpURLConnection) url.openConnection();
                    //if(chunkedStream)
                        //conn.setChunkedStreamingMode(chunkLen);
                    conn.setDoInput(true);
                    conn.setDoOutput(true);
                    conn.setUseCaches(false);
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Connection", "Keep-Alive");
                    conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                    conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                    conn.setRequestProperty(WEB_NAME, filePath);
                    dos = new DataOutputStream(conn.getOutputStream());
                    dos.writeBytes(twoHyphens + boundary + lineEnd);
                    dos.writeBytes("Content-Disposition: form-data; name=\"" + WEB_NAME + "\";filename=\""
                            + filePath + "\"" + lineEnd);
                    dos.writeBytes(lineEnd);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    buffer = new byte[bufferSize];
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                    //int progress;
                    //long length = 0;
                    while (bytesRead > 0) {
                        dos.write(buffer, 0, bufferSize);
                        /*if(chunkedStream) {
                            length += bufferSize;
                            progress = (int) (((float) length / (float) totalSize) * 100);
                        }*/
                        bytesAvailable = fileInputStream.available();
                        bufferSize = Math.min(bytesAvailable, maxBufferSize);
                        bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                    }
                    dos.writeBytes(lineEnd);
                    dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
                    serverResponseCode = conn.getResponseCode();
                    if (serverResponseCode == 200) {
                        serverResponseString = getServerResponse(conn);
                    } else {
                        serverResponseString = "HTTP RESPONSE CODE " + serverResponseCode;
                    }
                    fileInputStream.close();
                    dos.flush();
                    dos.close();
                } catch (MalformedURLException ex) {
                    ex.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            String finalServerResponseString = serverResponseString;
            runOnUiThread(() -> {
                int contentText;
                if ((finalServerResponseString != null) && (((fileText.getId() == R.id.fileUpload) && (finalServerResponseString.charAt(0) == '#')) || (fileText.getId() == R.id.soundUpload) && finalServerResponseString.equals("1"))) {
                    fileText.setBackgroundColor(Color.parseColor("#4000ff00"));
                    contentText = R.string.uploaded;
                    if((fileText.getId() == R.id.fileUpload)) {
                        ID = finalServerResponseString.substring(1, finalServerResponseString.indexOf('|'));
                        KEY = finalServerResponseString.substring(finalServerResponseString.indexOf('|') + 1);
                        //if (locationUploadEnabled) {
                            getLocation();
                        //}
                        //recordSound();
                        description();
                        Button shareButton = findViewById(R.id.share_last_uploaded);
                        shareButton.setOnClickListener(v -> shareText(URL + '?' + ID));
                        shareButton.setEnabled(true);
                        shareButton.setText(R.string.shareLastUploaded);
                        shareButton.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(R.drawable.ic_share), null, null);
                        shareButton.setVisibility(View.VISIBLE);
                        findViewById(R.id.layoutAfterShareButton).setVisibility(View.VISIBLE);
                    }
                    /*else if(fileText.getId() == R.id.soundUpload)   {
                        ((ViewGroup) voiceButton.getParent()).removeView(voiceButton);
                    }*/
                }
                else {
                    fileText.setBackgroundColor(Color.parseColor("#40ff0000"));
                    contentText = R.string.uploadError;
                    if(fileText.getId() == R.id.soundUpload)   {
                        setVoiceButtonEnabled(true);
                    }
                }
                Toast.makeText(getApplicationContext(), getString(text) + ": " + getString(contentText), Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    void uploadFileFromURI(Uri local_uri, String web_url/*, String web_name, int notificationTitle, int notificationIcon*/, int textView, int text, int drawable)    {
        try {
            uploadFile(/*null, */web_url/*, web_name"file"*/, getContentResolver().openInputStream(local_uri)/*, notificationTitle, notificationIcon*/, textView, text, drawable);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    void uploadPhotoVideo(Uri uri) {
        resetUploadStatuses();
        uploadFileFromURI(uri, URL + "media.php"/*, "file"*/, R.id.fileUpload, R.string.file, R.drawable.ic_photovideo);
    }
}